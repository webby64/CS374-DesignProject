import React from 'react';


export default function FinishedBookView() {
    return (
        <h2 style = {{"color" : "white"}}>Congratualations!</h2>
    )
}